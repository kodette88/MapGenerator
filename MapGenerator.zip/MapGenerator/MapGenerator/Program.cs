﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2
{
    class Program
    {
        static void Main(string[] args)
        {
            string mapFile = args[0];
            int partsCount = Convert.ToInt32(args[1]);

            MapGen gen = new MapGen();
            gen.Create(mapFile, partsCount);
            
            Console.WriteLine("Map Generated");
            Console.ReadLine();
        }

    }
}
