﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2
{
    class MapGen
    {
        public string templateDir = Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location) + @"\template\";

        public class XYCoordinates
        {
            public long x;
            public long y;

            public XYCoordinates(long X, long Y)
            {
                x = X;
                y = Y;
            }
        }

        public class XYZCoordinates
        {
            public long x;
            public long y;
            public long z;

            public XYZCoordinates(long X, long Y, long Z)
            {
                x = X;
                y = Y;
                z = Z;
            }
        }

        public struct Plane
        {
            public XYZCoordinates x;
            public XYZCoordinates y;
            public XYZCoordinates z;
        }

        public struct Part
        {
            public const int start_top = 0;
            public const int start_bottom = 1;
            public const int corner_bottomleft = 2;
            public const int corner_bottomright = 3;
            public const int corner_topleft = 4;
            public const int corner_topright = 5;
            public const int hallway_vertical = 6;
            public const int hallway_horizontal = 7;
        }

        public string PartToString(int part)
        {
            switch (part)
            {
                case Part.start_bottom:
                default:
                    return "start_bottom";
                case Part.start_top:
                    return "start_top";
                case Part.corner_bottomleft:
                    return "corner_bottomleft";
                case Part.corner_bottomright:
                    return "corner_bottomright";
                case Part.corner_topleft:
                    return "corner_topleft";
                case Part.corner_topright:
                    return "corner_topright";
                case Part.hallway_vertical:
                    return "hallway_vertical";
                case Part.hallway_horizontal:
                    return "hallway_horizontal";
            }
        }

        public string MoveToString(int move)
        {
            switch (move)
            {
                case Move.Down:
                default:
                    return "down";
                case Move.Up:
                    return "up";
                case Move.Left:
                    return "left";
                case Move.Right:
                    return "right";
            }
        }

        public struct Move
        {
            public const int Down = 0;
            public const int Up = 1;
            public const int Left = 2;
            public const int Right = 3;
        }

        public void parseTemplate(string dir)
        {
            foreach (string file in Directory.GetFiles(dir, "*.vmf"))
            {
                if ((Path.GetFileName(file).Equals("template.vmf", StringComparison.OrdinalIgnoreCase)) ||
                    (Path.GetFileName(file).Equals("new.vmf", StringComparison.OrdinalIgnoreCase)))
                {
                    continue;
                }

                if ((!Path.GetFileName(file).Contains("_up.vmf")) &&
                    (!Path.GetFileName(file).Contains("_right.vmf")))
                {
                    string fileMovedUp = file.Replace(".vmf", "_up.vmf");
                    string fileMovedRight = file.Replace(".vmf", "_right.vmf");

                    savePlaneDiff(file, fileMovedUp);
                    savePlaneDiff(file, fileMovedRight);

                    Console.WriteLine("Parsed: " + Path.GetFileNameWithoutExtension(file));
                }
            }
        }

        public void savePlaneDiff(string fileOrig, string fileMoved)
        {
            List<Plane> planesOrig = getPlanes(fileOrig);
            List<Plane> planesUp = getPlanes(fileMoved);

            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < planesOrig.Count(); i++)
            {
                Plane diff = comparePlanes(planesOrig[i], planesUp[i]);

                string plane = "\"plane\" \"(" + diff.x.x + " " + diff.x.y + " " + diff.x.z + ") (" + diff.y.x + " " + diff.y.y + " " + diff.y.z + ") (" + diff.z.x + " " + diff.z.y + " " + diff.z.z + ")\"";
                sb.AppendLine(plane);

                System.Diagnostics.Trace.WriteLine("[" + Path.GetFileNameWithoutExtension(fileOrig) + "] " + plane);
            }

            string file = fileMoved.Replace(".vmf", "_diff.dat");
            if (File.Exists(file))
            {
                File.Delete(file);
            }
            File.WriteAllText(file, sb.ToString());
        }

        public Plane comparePlanes(Plane plane1, Plane plane2)
        {
            Plane ret = new Plane();
            ret.x.x = plane2.x.x - plane1.x.x;
            ret.x.y = plane2.x.y - plane1.x.y;
            ret.x.z = plane2.x.z - plane1.x.z;

            ret.y.x = plane2.y.x - plane1.y.x;
            ret.y.y = plane2.y.y - plane1.y.y;
            ret.y.z = plane2.y.z - plane1.y.z;

            ret.z.x = plane2.z.x - plane1.z.x;
            ret.z.y = plane2.z.y - plane1.z.y;
            ret.z.z = plane2.z.z - plane1.z.z;

            //Plane Difference
            return ret;
        }

        public List<Plane> getPlanes(string file)
        {
            List<Plane> planes = new List<Plane>();
            using (StringReader reader = new StringReader(File.ReadAllText(file)))
            {
                string line = string.Empty;
                do
                {
                    line = reader.ReadLine();

                    if ((!String.IsNullOrEmpty(line)) && (line.Contains("\"plane\" ")))
                    {
                        string[] str = line.Split(new string[] { "\"plane\" " }, StringSplitOptions.None);

                        str[1] = str[1].Replace("\"", "");
                        str[1] = str[1].Replace("(", "");
                        str[1] = str[1].Replace(")", "");

                        string[] val = str[1].Split(new string[] { " " }, StringSplitOptions.None);

                        Plane plane = new Plane();
                        plane.x.x = Convert.ToInt32(val[0]);
                        plane.x.y = Convert.ToInt32(val[1]);
                        plane.x.z = Convert.ToInt32(val[2]);

                        plane.y.x = Convert.ToInt32(val[3]);
                        plane.y.y = Convert.ToInt32(val[4]);
                        plane.y.z = Convert.ToInt32(val[5]);

                        plane.z.x = Convert.ToInt32(val[6]);
                        plane.z.y = Convert.ToInt32(val[7]);
                        plane.z.z = Convert.ToInt32(val[8]);

                        planes.Add(plane);
                    }
                } while (line != null);
            }
            return planes;
        }

        struct NewPartStruct
        {
            public int direction;
            public int part;
        }

        private NewPartStruct AddPart(int part, int direction)
        {
            NewPartStruct newPart = new NewPartStruct();
            newPart.part = part;
            newPart.direction = direction;
            return newPart;
        }

        private NewPartStruct GetLastPart(List<NewPartStruct> parts)
        {
            return parts[parts.Count - 1];
        }


        private List<NewPartStruct> GenerateParts(int count)
        {
            Random rnd = new Random();

            List<NewPartStruct> parts = new List<NewPartStruct>();

            parts.Add(AddPart(Part.start_top, Move.Up));

            List<int> possible_parts = new List<int>();

            for (int i = 1; i < count; i++)
            {
                possible_parts.Clear();

                NewPartStruct last_part = GetLastPart(parts);

                switch (last_part.part)
                {
                    case Part.start_top:
                        //vert, topright, topleft
                        possible_parts.Add(Part.hallway_vertical);
                        possible_parts.Add(Part.corner_topright);
                        possible_parts.Add(Part.corner_topleft);
                        break;
                    case Part.start_bottom:
                        //vert, bottomright, bottomleft
                        possible_parts.Add(Part.hallway_vertical);
                        possible_parts.Add(Part.corner_bottomright);
                        possible_parts.Add(Part.corner_bottomleft);
                        break;
                    case Part.corner_bottomleft:
                        //vert, topright, topleft
                        possible_parts.Add(Part.hallway_vertical);
                        possible_parts.Add(Part.corner_topright);
                        possible_parts.Add(Part.corner_topleft);
                        break;
                    case Part.corner_bottomright:
                        //vert, topright, topleft
                        possible_parts.Add(Part.hallway_vertical);
                        possible_parts.Add(Part.corner_topright);
                        possible_parts.Add(Part.corner_topleft);
                        break;
                    case Part.corner_topleft:
                        //horz, bottomright 
                        possible_parts.Add(Part.hallway_horizontal);
                        possible_parts.Add(Part.corner_bottomright);
                        break;
                    case Part.corner_topright:
                        //horz, bottomleft
                        possible_parts.Add(Part.hallway_horizontal);
                        possible_parts.Add(Part.corner_bottomleft);
                        break;
                    case Part.hallway_horizontal:
                        //horz
                        possible_parts.Add(Part.hallway_horizontal);
                        if (last_part.direction == Move.Left)
                        {
                            //bottomleft
                            possible_parts.Add(Part.corner_bottomleft);
                        }
                        else if (last_part.direction == Move.Right)
                        {
                            //bottomright
                            possible_parts.Add(Part.corner_bottomright);
                        }
                        break;
                    case Part.hallway_vertical:
                        //vert 
                        possible_parts.Add(Part.hallway_vertical);
                        possible_parts.Add(Part.corner_topleft);
                        possible_parts.Add(Part.corner_topright);
                        break;
                }

                NewPartStruct new_part = new NewPartStruct();
                new_part.part = possible_parts[rnd.Next(0, possible_parts.Count)];

                switch (new_part.part)
                {
                    case Part.start_top:
                        new_part.direction = Move.Up;
                        break;
                    case Part.start_bottom:
                        new_part.direction = Move.Down;
                        break;
                    case Part.corner_bottomleft:
                        new_part.direction = Move.Up;
                        break;
                    case Part.corner_bottomright:
                        new_part.direction = Move.Up;
                        break;
                    case Part.corner_topleft:
                        new_part.direction = Move.Right;
                        break;
                    case Part.corner_topright:
                        new_part.direction = Move.Left;
                        break;
                    case Part.hallway_horizontal:
                        new_part.direction = parts[parts.Count - 1].direction;
                        break;
                    case Part.hallway_vertical:
                        new_part.direction = Move.Up;
                        break;
                }
                parts.Add(new_part);
            }

            NewPartStruct final_part = parts[parts.Count - 1];
            switch (final_part.part)
            {
                case Part.corner_bottomleft:
                    break;
                case Part.corner_bottomright:
                    break;
                case Part.corner_topleft:
                    parts.Add(AddPart(Part.corner_bottomright, Move.Up));
                    break;
                case Part.corner_topright:
                    parts.Add(AddPart(Part.corner_bottomleft, Move.Up));
                    break;
                case Part.hallway_horizontal:
                    switch (final_part.direction)
                    {
                        case Move.Left:
                            parts.Add(AddPart(Part.corner_bottomleft, Move.Up));
                            break;
                        case Move.Right:
                            parts.Add(AddPart(Part.corner_bottomright, Move.Up));
                            break;
                    }
                    break;
                case Part.hallway_vertical:
                    break;
            }
            parts.Add(AddPart(Part.start_bottom, Move.Up));

            return parts;
        }


        private class Entity
        {
            public long id;
            public string classname;
            public XYZCoordinates angles = new XYZCoordinates(0, 90, 0);
            public bool enabled = true;
            public XYZCoordinates origin = new XYZCoordinates(0, 0, 0);
            public Editor editor = new Editor();
        }

        private class Editor
        {
            public XYZCoordinates color = new XYZCoordinates(220, 30, 220);
            public bool visgroupshown = true;
            public bool visgroupautoshown = true;
            public XYCoordinates logicalpos = new XYCoordinates(0, 0);
        }


        private List<Entity> GetEntitiesByPart(int part)
        {
            StringBuilder data = new StringBuilder();

            List<Entity> entities = new List<Entity>();

            bool write = false;
            using (StringReader reader = new StringReader(File.ReadAllText(templateDir + PartToString(part) + ".vmf")))
            {
                string line = string.Empty;
                do
                {
                    line = reader.ReadLine();

                    if (String.IsNullOrEmpty(line)) continue;

                    if (line.EndsWith("entity"))
                    {
                        write = true;
                    }
                    if (write)
                    {
                        data.AppendLine(line);
                    }
                    if ((write) && (line == "}"))
                    {
                        write = false;

                        Entity entity = AddEntity(data.ToString());
                        entities.Add(entity);

                        data.Clear();
                    }

                } while (line != null);
            }

            return entities;
        }

        private Entity AddEntity(string data)
        {
            Entity entity = new Entity();
            using (StringReader reader = new StringReader(data))
            {
                string line = string.Empty;
                do
                {
                    line = reader.ReadLine();

                    if ( (String.IsNullOrEmpty(line)) || 
                        (line.EndsWith("entity")) || (line.EndsWith("editor")) ||
                        (line.EndsWith("{")) || (line.EndsWith("}"))) { continue; }

                    string key = GetKey(line);
                    switch (key)
                    {
                        case "id":
                            entity.id = 0; //(long) GetValueByKey(line, key);
                            break;
                        case "classname":
                            entity.classname = (string)GetValueByKey(line, key);
                            break;
                        case "angles":
                            entity.angles = ConvertStringToXYZ((string)GetValueByKey(line, key));
                            break;
                        case "enabled":
                            entity.enabled = true;
                            //entity.enabled = Convert.ToBoolean((int)GetValueByKey(line, key));
                            break;
                        case "origin":
                            entity.origin = ConvertStringToXYZ((string)GetValueByKey(line, key));
                            break;
                        case "color":
                            entity.editor.color = ConvertStringToXYZ((string)GetValueByKey(line, key));
                            break;
                        case "visgroupshown":
                            //entity.editor.visgroupshown = Convert.ToBoolean((int)GetValueByKey(line, key));
                            entity.editor.visgroupshown = true;
                            break;
                        case "visgroupautoshown":
                            //entity.editor.visgroupautoshown = Convert.ToBoolean((int)GetValueByKey(line, key));
                            entity.editor.visgroupautoshown = true;
                            break;
                        case "logicalpos":
                            entity.editor.logicalpos = ConvertStringToXY((string)GetValueByKey(line, key));
                            break;
                    }
                } while (line != null);
            }
            return entity;
        }

        private XYCoordinates ConvertStringToXY(string data)
        {
            data = data.Replace("[", "");
            data = data.Replace("]", "");
            long[] val = Array.ConvertAll(data.Split(new string[] { " " }, StringSplitOptions.None), long.Parse);
            XYCoordinates xyz = new XYCoordinates(val[0], val[1]);
            return xyz;
        }

        private XYZCoordinates ConvertStringToXYZ(string data)
        {
            long[] val = Array.ConvertAll(data.Split(new string[] { " " }, StringSplitOptions.None), long.Parse);
            XYZCoordinates xyz = new XYZCoordinates(val[0], val[1], val[2]);
            return xyz;
        }

        private object GetValueByKey(string data, string key)
        {
            return data.Split(new string[] { "\"" + key + "\" \"" }, StringSplitOptions.None)[1]
                .Split(new string[] { "\"" }, StringSplitOptions.None)[0];
        }

        private string GetKey(string data)
        {
            return data.Split(new string[] { "\"" }, StringSplitOptions.None)[1]
                .Split(new string[] { "\"" }, StringSplitOptions.None)[0];
        }

        private string GetPartSolids(int part)
        {
            StringBuilder data = new StringBuilder();

            bool solid = false;
            using (StringReader reader = new StringReader(File.ReadAllText(templateDir + PartToString(part) + ".vmf")))
            {
                string line = string.Empty;
                do
                {
                    line = reader.ReadLine();

                    if (String.IsNullOrEmpty(line)) continue;

                    if (line.EndsWith("solid"))
                    {
                        solid = true;
                    }
                    else if ((solid) && (line == "}"))
                    {
                        return data.ToString();
                    }

                    if (solid)
                    {
                        data.AppendLine(line);
                    }
                } while (line != null);
            }

            return String.Empty;
        }

        private string EntitiesToString(List<Entity> entities)
        {
            StringBuilder ret = new StringBuilder();
            foreach (Entity entity in entities)
            {
                ret.AppendLine("entity");
                ret.AppendLine("{");
                ret.AppendLine("    \"id\" \"" + entity.id + "\"");
                ret.AppendLine("    \"classname\" \"" + entity.classname + "\"");
                ret.AppendLine("    \"angles\" \"" + entity.angles.x + " " + entity.angles.y + " " + entity.angles.z + "\"");
                ret.AppendLine("    \"enabled\" \"" + Convert.ToInt32(entity.enabled) + "\"");
                ret.AppendLine("    \"origin\" \"" + entity.origin.x + " " + entity.origin.y + " " + entity.origin.z + "\"");
                ret.AppendLine("    editor");
                ret.AppendLine("    {");
                ret.AppendLine("        \"color\" \"" + entity.editor.color.x + " " + entity.editor.color.y + " " + entity.editor.color.z + "\"");
                ret.AppendLine("        \"visgroupshown\" \"" + Convert.ToInt32(entity.editor.visgroupshown) + "\"");
                ret.AppendLine("        \"visgroupautoshown\" \"" + Convert.ToInt32(entity.editor.visgroupautoshown) + "\"");
                ret.AppendLine("        \"logicalpos\" \"[" + entity.editor.logicalpos.x + " " + entity.editor.logicalpos.y + "]\"");
                ret.AppendLine("    }");
                ret.AppendLine("}");
            }
            return ret.ToString();
        }

        private GeneratedMapStruct GenerateMap(int partsCount)
        {
            int part_size = 192;
            int id = 1;

            int moved_X = 0;
            int moved_Y = 0;

            StringBuilder map = new StringBuilder();

            List<NewPartStruct> parts = GenerateParts(partsCount);
            foreach (NewPartStruct part in parts)
            {
                Console.WriteLine(PartToString(part.part) + " move: " + MoveToString(part.direction));

                string partSolids = GetPartSolids(part.part);
                using (StringReader reader = new StringReader(partSolids))
                {
                    string line = string.Empty;
                    do
                    {
                        id = id + 1;

                        line = reader.ReadLine();

                        if (String.IsNullOrEmpty(line)) continue;

                        if (line.Contains("\"plane\" "))
                        {
                            string[] str = line.Split(new string[] { "\"plane\" " }, StringSplitOptions.None);

                            str[1] = str[1].Replace("\"", "");
                            str[1] = str[1].Replace("(", "");
                            str[1] = str[1].Replace(")", "");

                            long[] val = Array.ConvertAll(str[1].Split(new string[] { " " }, StringSplitOptions.None), long.Parse);

                            //(val[0] val[1] val[2]) (val[3] val[4] val[5]) (val[6] val[7] val[8])
                            switch (part.direction)
                            {
                                case Move.Down:
                                    val[0] = val[0] + (part_size * moved_X);
                                    val[1] = val[1] - (part_size * moved_Y);
                                    val[2] = val[2];

                                    val[3] = val[3] + (part_size * moved_X);
                                    val[4] = val[4] - (part_size * moved_Y);
                                    val[5] = val[5];

                                    val[6] = val[6] + (part_size * moved_X);
                                    val[7] = val[7] - (part_size * moved_Y);
                                    val[8] = val[8];
                                    break;
                                case Move.Up:
                                    val[0] = val[0] + (part_size * moved_X);
                                    val[1] = val[1] + (part_size * moved_Y);
                                    val[2] = val[2];

                                    val[3] = val[3] + (part_size * moved_X);
                                    val[4] = val[4] + (part_size * moved_Y);
                                    val[5] = val[5];

                                    val[6] = val[6] + (part_size * moved_X);
                                    val[7] = val[7] + (part_size * moved_Y);
                                    val[8] = val[8];
                                    break;
                                case Move.Left:
                                    val[0] = val[0] - (part_size * -moved_X);
                                    val[1] = val[1] + (part_size * moved_Y);
                                    val[2] = val[2];

                                    val[3] = val[3] - (part_size * -moved_X);
                                    val[4] = val[4] + (part_size * moved_Y);
                                    val[5] = val[5];

                                    val[6] = val[6] - (part_size * -moved_X);
                                    val[7] = val[7] + (part_size * moved_Y);
                                    val[8] = val[8];
                                    break;
                                case Move.Right:
                                    val[0] = val[0] + (part_size * moved_X);
                                    val[1] = val[1] + (part_size * moved_Y);
                                    val[2] = val[2];

                                    val[3] = val[3] + (part_size * moved_X);
                                    val[4] = val[4] + (part_size * moved_Y);
                                    val[5] = val[5];

                                    val[6] = val[6] + (part_size * moved_X);
                                    val[7] = val[7] + (part_size * moved_Y);
                                    val[8] = val[8];
                                    break;
                            }

                            line = str[0] + "\"plane\" \"(" + val[0] + " " + val[1] + " " + val[2] + ") (" + val[3] + " " + val[4] + " " + val[5] + ") (" + val[6] + " " + val[7] + " " + val[8] + ")\"";
                        }
                        else if ((!String.IsNullOrEmpty(line)) && (line.Contains("\"id\" ")))
                        {
                            string[] str = line.Split(new string[] { "\"id\" " }, StringSplitOptions.None);
                            line = str[0] + "\"id\" \"" + id + "\"";
                        }
                        map.AppendLine(line);
                    } while (line != null);
                }

                switch (part.direction)
                {
                    case Move.Down:
                        moved_Y = moved_Y - 1;
                        break;
                    case Move.Up:
                        moved_Y = moved_Y + 1;
                        break;
                    case Move.Left:
                        moved_X = moved_X - 1;
                        break;
                    case Move.Right:
                        moved_X = moved_X + 1;
                        break;
                }
            }
            
            StringBuilder entitiesBuilder = new StringBuilder();
            
            NewPartStruct firstPart = parts[0];
            List<Entity> entities = GetEntitiesByPart(firstPart.part);
            PositionEntities(entities, id, 0, 0, part_size);
            entitiesBuilder.Append(EntitiesToString(entities));

            NewPartStruct lastPart = parts[parts.Count - 1];
            entities = GetEntitiesByPart(lastPart.part);
            PositionEntities(entities, id, moved_X, moved_Y - 1, part_size);
            entitiesBuilder.Append(EntitiesToString(entities));

            GeneratedMapStruct generatedMap = new GeneratedMapStruct();
            generatedMap.world = map.ToString();
            generatedMap.entities = entitiesBuilder.ToString();

            return generatedMap;
        }

        private List<Entity> PositionEntities(List<Entity> entities, long id, long moved_X, long moved_Y, int part_size = 192)
        {
            foreach (Entity entity in entities)
            {
                id = id + 1;

                entity.id = id;
                entity.origin = new XYZCoordinates(
                                    entity.origin.x + (part_size * moved_X),
                                    entity.origin.y + (part_size * moved_Y),
                                    entity.origin.z
                                    );
            }
            return entities;
        }

        struct GeneratedMapStruct
        {
            public string world;
            public string entities;
        }

        public void Create(string fileBSP, int partsCount = 10)
        {
            string fileVMF = Path.GetTempPath() + @"\" + Path.GetFileNameWithoutExtension(fileBSP) + ".vmf";

            StringBuilder map = new StringBuilder();

            GeneratedMapStruct generatedMap = GenerateMap(partsCount);

            bool world = false;
            using (StringReader reader = new StringReader(File.ReadAllText(templateDir + @"new.vmf")))
            {
                string line = string.Empty;
                do
                {
                    line = reader.ReadLine();

                    if (String.IsNullOrEmpty(line)) continue;

                    if (line == "world")
                    {
                        world = true;
                    }
                    else if ((world) && (line == "}"))
                    {
                        //insert map data
                        map.AppendLine(generatedMap.world);

                        world = false;
                    }

                    map.AppendLine(line);
                } while (line != null);
            }

            map.Append(generatedMap.entities);

            //string partEntities = GetEntitiesByPart(Part.start_top).ToString();
            //map.Append(partEntities);

            File.WriteAllText(fileVMF, map.ToString());
            CompileMap(fileVMF, fileBSP);
        }



        private void RunProcess(string file, string args)
        {
            Process p = new Process();
            p.StartInfo.FileName = file;
            p.StartInfo.Arguments = args;
            p.StartInfo.WorkingDirectory = Path.GetDirectoryName(p.StartInfo.FileName);
            p.StartInfo.CreateNoWindow = true;
            p.StartInfo.ErrorDialog = false;
            p.StartInfo.RedirectStandardError = true;
            p.StartInfo.RedirectStandardOutput = true;
            p.StartInfo.UseShellExecute = false;

            p.ErrorDataReceived += (sendingp, errorLine) => Console.WriteLine(errorLine.Data);
            p.OutputDataReceived += (sendingp, dataLine) => Console.WriteLine(dataLine.Data);

            p.Start();
            p.BeginErrorReadLine();
            p.BeginOutputReadLine();

            p.WaitForExit();
        }

        public void CompileMap(string fileVMF, string fileBSP)
        {
            string sdkDir = @"E:\GAMES\Steam\steamapps\common\Counter-Strike Global Offensive\bin\";
            string gameDir = @"E:\GAMES\Steam\steamapps\common\Counter-Strike Global Offensive\csgo";
            //string mapsDir = @"E:\GAMES\Steam\steamapps\common\Counter-Strike Global Offensive\csgo\maps\";

            RunProcess(sdkDir + @"vbsp.exe", "-game \"" + gameDir + "\" \"" + fileVMF + "\"");
            RunProcess(sdkDir + @"vvis.exe", "-game \"" + gameDir + "\" \"" + fileBSP + "\"");
            RunProcess(sdkDir + @"vrad.exe", "-game \"" + gameDir + "\" \"" + fileBSP + "\"");

            string fileCompiled = Path.GetDirectoryName(fileVMF) + @"\" + Path.GetFileNameWithoutExtension(fileVMF) + ".bsp";
            if (File.Exists(fileBSP))
            {
                File.Delete(fileBSP);
            }
            File.Move(fileCompiled, fileBSP);
        }
    }
}
